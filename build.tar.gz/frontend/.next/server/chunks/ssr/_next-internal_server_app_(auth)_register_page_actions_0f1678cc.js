module.exports=[59369,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28auth%29_register_page_actions_0f1678cc.js.map