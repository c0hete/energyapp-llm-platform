module.exports=[86439,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_settings_page_actions_5db1aa32.js.map